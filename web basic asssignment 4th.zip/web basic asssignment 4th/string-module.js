function palindrome(string) {
  var text = string.toLowerCase();
  return text === text.split('').reverse().join('');
}

function upper(string) {
  return string.toUpperCase();
}

function search(sites) {
  var count = 0;

  for (var i = 0; i < sites.length; i++) {
    if (sites[i].toLowerCase().includes('www')) {
      count++;
    }
  }

  return count;
}

module.exports = {
  palindrome,
  upper,
  search
};
