var stringModule = require('./string-module');

console.log('Palindrome:', stringModule.palindrome('madam'));
console.log('Uppercase:', stringModule.upper('hello world'));

var websites = [
  'www.google.com',
  'www.msn.com',
  'www.amazon.co.in',
  'answers.yahoo.com',
  'en.m.wikipedia.com',
  'codehs.github.io',
  'www.coderanch.com'
];

console.log('Websites containing www:', stringModule.search(websites));
