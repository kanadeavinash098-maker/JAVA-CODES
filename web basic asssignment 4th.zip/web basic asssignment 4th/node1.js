function min(numbers) {
	var minimum = numbers[0];

	for (var i = 1; i < numbers.length; i++) {
		if (numbers[i] < minimum) {
			minimum = numbers[i];
		}
	}

	return minimum;
}

var numbers = [25, 8, 42, 3, 19];
console.log("Minimum value:", min(numbers));
