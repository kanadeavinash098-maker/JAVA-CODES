console.log("Order placed!");

setTimeout(() => {
    console.log("Confirming order...");
    
    setTimeout(() => {
        console.log("Order confirmed!");
    }, 2000);

}, 3000);