function f1(number) {
	if (number % 15 === 0) return "f1";
	if (number % 3 === 0) return "f2";
	if (number % 5 === 0) return "b3";
	return number;
}

var result = Array.from({ length: 100 }, function (_, index) {
	return f1(index + 1);
});

console.log(result.join("\n"));
