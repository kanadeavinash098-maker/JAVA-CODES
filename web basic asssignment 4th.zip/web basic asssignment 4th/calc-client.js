var calc = require('./calc');

console.log('Add:', calc.add(10, 5));
console.log('Subtract:', calc.subtract(10, 5));
console.log('Multiply:', calc.multiply(10, 5));
console.log('Divide:', calc.divide(10, 5));
console.log('Square:', calc.square(5));
console.log('Minimum:', calc.min(10, 5, 20));
console.log('Maximum:', calc.max(10, 5, 20));
