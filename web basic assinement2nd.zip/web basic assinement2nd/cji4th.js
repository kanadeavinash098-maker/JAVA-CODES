function convertToCm(inches) {
    var cm = inches * 2.54;
    console.log(inches + " inches = " + cm + " cm");
    document.write(inches + " inches = " + cm + " cm<br>");
}